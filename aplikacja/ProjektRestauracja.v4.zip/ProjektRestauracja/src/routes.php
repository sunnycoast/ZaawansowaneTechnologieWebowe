<?php

use Symfony\Component\Routing\RouteCollection;
use Symfony\Component\Routing\Route;

$routes = new RouteCollection();

$routes->add('start', new Route( '', array(
        '_controller' => 'MVC\\Controller\\StartController::indexAction'
    )));

$routes->add('gosc_logowanie', new Route( '/gosc_logowanie', array(
    '_controller' => 'MVC\\Controller\\GoscLogowanieController::indexAction'
)));

$routes->add('zamowienie', new Route( '/{imie}/zamowienie', array(
    '_controller' => 'MVC\\Controller\\GoscLogowanieController::indexAction'
)));

$routes->add('pracownik_logowanie', new Route( '/pracownik_logowanie', array(
    '_controller' => 'MVC\\Controller\\PracownikLogowanieController::indexAction'
)));

$routes->add('staly_klient_logowanie', new Route( '/staly_klient_logowanie', array(
    '_controller' => 'MVC\\Controller\\StalyKlientLogowanieController::indexAction'
)));

return $routes;
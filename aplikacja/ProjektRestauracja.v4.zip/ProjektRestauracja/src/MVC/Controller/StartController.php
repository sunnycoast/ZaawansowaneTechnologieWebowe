<?php

namespace MVC\Controller;

use Base\App;

class StartController extends App
{
    public function indexAction()
    {
        /*
        $em =$this-> getEntityManager();
        $rows = $em->getRepository('MVC\Model\Kategoria')->findAll();
        foreach ($rows as $row)
        {
            echo($row->getKolorKategorii().'<br>');
        }
        die;
        // */

        return $this->render('MVC/View/start.html.twig', array());
    }
}
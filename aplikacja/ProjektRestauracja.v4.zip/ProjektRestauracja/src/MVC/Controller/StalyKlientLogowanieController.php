<?php

namespace MVC\Controller;

use Base\App;

class StalyKlientLogowanieController extends App
{
    public function indexAction()
    {
        if( isset($_POST['email']) && isset($_POST['haslo']))
        {
            $email 	= $_POST['email'];
            $haslo   = $_POST['haslo'];
            $err = 'przeszlo';

            $render = $this->render('MVC/View/staly_klient_logowanie.html.twig', array(
                'email'  => $email,
                'err'    => $err
            ));
        } else
        {
            $render = $this->render('MVC/View/staly_klient_logowanie.html.twig', array(
                'email'  => '',
                'err'    => ''
            ));
        }
        return $render;
    }
}
<?php

namespace MVC\Model;

/**
 * @Entity @Table(name="rachunki")
 **/
class Rachunek
{
    /** @Id @Column(type="integer") @GeneratedValue */
    protected $IdRachunku;

    /** @Column(type="string") */
    protected $NaImie;

    /** @Column(type="integer") */
    protected $LiczbaOsob;

    /** @Column(type="datetime") */
    protected $DataOtwarcia;

    /** @Column(type="datetime") */
    protected $DataZamkniecia;

    /** @Column(type="string") */
    protected $UwagiPracownika;

    /** @Column(type="string") */
    protected $UwagiGoscia;

    /**
     * @ManyToOne (targetEntity = "Stolik")
     * @JoinColumn (name = "IdStolika", referencedColumnName = "id")
     * @Column(type="integer")
     */
    protected $IdStolika;

    /** @Column(type="integer") */
    protected $IdStalegoKlienta;

    public function getIdRachunku()
    {    return $this->IdRachunku;    }

    public function getNaImie()
    {    return $this->NaImie;    }

    public function setNaImie($NaImie)
    {    $this->NaImie = $NaImie;    }

    public function getLiczbaOsob()
    {    return $this->LiczbaOsob;    }

    public function setLiczbaOsob($LiczbaOsob)
    {    $this->LiczbaOsob = $LiczbaOsob;    }

    public function getDataOtwarcia()
    {    return $this->DataOtwarcia;    }

    public function setDataOtwarcia()
    {    $this->DataOtwarcia = new \DateTime("now");    }

    public function getDataZamkniecia()
    {    return $this->DataZamkniecia;    }

    public function setDataZamkniecia()
    {    $this->DataZamkniecia = new \DateTime("now");    }

    public function getUwagiPracownika()
    {    return $this->UwagiPracownika;    }

    public function setUwagiPracownika($UwagiPracownika)
    {    $this->UwagiPracownika = $UwagiPracownika;    }

    public function getUwagiGoscia()
    {    return $this->UwagiGoscia;    }

    public function setUwagiGoscia($UwagiGoscia)
    {    $this->UwagiGoscia = $UwagiGoscia;    }

    public function getIdStolika()
    {    return $this->IdStolika;    }

    public function setIdStolika($IdStolika)
    {    $this->IdStolika = $IdStolika;    }

    public function getIdStalegoKlienta()
    {    return $this->IdStalegoKlienta;    }

    public function setIdStalegoKlienta($IdStalegoKlienta)
    {    $this->IdStalegoKlienta = $IdStalegoKlienta;    }

}
<?php

namespace MVC\Model;

/**
 * @Entity @Table(name="vat")
 **/
class VAT
{
    /** @Id @Column(type="integer") @GeneratedValue **/
    protected $IdVAT;

    /** @Column(type="integer") **/
    protected $StawkaVAT;

    /** @Column(type="string") **/
    protected $Dotyczy;

    /**
     * @OneToMany (targetEntity = "PozycjaMenu", mappedBy="pozycje_menu")
     */
    protected $IdPozycjiMenu;

    public function __construct()
    {
        $this->IdPozycjiMenu = new ArrayCollection();
    }

    public function getIdVAT()
    {    return $this->IdVAT;    }

    public function getStawkaVAT()
    {    return $this->StawkaVAT;    }

    public function setStawkaVAT($StawkaVAT)
    {    $this->StawkaVAT = $StawkaVAT;    }

    public function getDotyczy()
    {    return $this->Dotyczy;    }

    public function setDotyczy($Dotyczy)
    {    $this->Dotyczy = $Dotyczy;    }

    public function getIdPozycjiMenu()
    {    return $this->IdPozycjiMenu;    }

}
<?php

namespace MVC\Model;

/**
 * @Entity @Table(name="kategorie")
 **/
class Kategoria
{
    /** @Id @Column(type="integer") @GeneratedValue **/
    protected $IdKategorii;

    /** @Column(type="string") **/
    protected $NazwaKategorii;

    /** @Column(type="string") **/
    protected $KolorKategorii;

    /**
     * @OneToMany (targetEntity = "Produkt", mappedBy="kategorie")
     */
    protected $IdProduktu;

    public function __construct()
    {
        $this->IdProduktu = new ArrayCollection();
    }

    public function getIdKategorii()
    {    return $this->IdKategorii;    }

    public function getNazwaKategorii()
    {    return $this->NazwaKategorii;    }

    public function setNazwaKategori($NazwaKategorii)
    {    $this->NazwaKategorii = $NazwaKategorii;    }

    public function getKolorKategorii()
    {    return $this->KolorKategorii;    }

    public function setKolorKategorii($KolorKategorii)
    {    $this->KolorKategorii = $KolorKategorii;    }

    public function getIdProduktu()
    {    return $this->IdProduktu;    }

}
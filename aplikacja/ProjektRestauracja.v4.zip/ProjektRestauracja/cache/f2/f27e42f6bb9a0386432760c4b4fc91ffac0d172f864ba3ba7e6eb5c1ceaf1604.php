<?php

/* MVC/View/Layouts/zamowienie.html.twig */
class __TwigTemplate_44e4fbe1130682f4dd853a8e56e8c9bcafb28eb6179ce424f1bc462bf1cfb390 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC/View/Layouts/zamowienie.html.twig", 1);
        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_sources($context, array $blocks = array())
    {
        // line 4
        echo "    <title>Projekt Restauracja</title>
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script type=\"text/javascript\" src=\"";
        // line 6
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/zegar.js")), "html", null, true);
        echo "\"></script>
    <script>
        window.onload=zegar;
    </script>
    <style>

        .boix
        {
            padding: 2%;
            width: \t96%;
            height: 80%;
            display: -webkit-box;
            -webkit-box-orient: horizontal;
        }

        .pZam
        {    border: 3px solid steelblue;    }


        .pKat
        {
            border-top:    3px solid steelblue;
            border-right:  3px solid steelblue;
            border-bottom: 3px solid steelblue;
            height: 538px;
        }

        .cBattonNavKat
        {
            position: relative;
            background-color: steelblue;
            color: black;
            padding: 16px;
            font-size: 16px;
            width: 49.5%;
            height: 10%;
            cursor: pointer;
            border-top-right-radius: 50px;
            border-top-left-radius:  10px;
        }

        .cBattonNavZam
        {
            position: relative;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 16px;
            width: 49.5%;
            height: 10%;
            cursor: pointer;
            border-top-right-radius: 50px;
            border-top-left-radius:  10px;
        }

        .f1Batton
        {
            margin-left: 2%;
            width: 42%;
            position: relative;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 24px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .f2Batton
        {
            top: -50px;
            margin-left: 46%;
            width: 42%;
            position: relative;
            background-color: red;
            color: black;
            padding: 16px;
            font-size: 16px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .nav
        {
            position: relative;
            overflow: hidden;
            height: 54px;
        }

        .zeg
        {
            margin-left: 90%;
            width: 8%;
            text-align: center;
            position: absolute;
            color: black;
            font-size: 20px;
        }

        .cBattonKat
        {
            margin:2%;
            width:20%;
            height:13%;
            border-radius: 5px;
            cursor: pointer;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .c
        {    text-align: center;    }

        .cKategoria:hover .cDivOp
        {
            visibility: visible;
        }

        .boix > .zam
        {
            width: 33%;
            overflow: hidden;
        }

        .pZam
        {    height: 538px;    }

        .boix >.kat
        {    width: 67%;    }

        .pKat
        {    height: 538px;    }

        #pZaP
        {
            margin-top: 200px;
            font-size: 24px;
            font-weight: bold;
        }

    </style>
";
    }

    // line 155
    public function block_main($context, array $blocks = array())
    {
        // line 156
        echo "    <div class=\"boix\">
        <div class=\"zam\">
            <button id=\"sub1\" class=\"cBattonNavZam\" onclick=\"zamPods()\" disabled>Zamówienie</button>
            <button class=\"cBattonNavKat\"  onclick=\"kafelki(kategorie())\">Kategorie</button>
            <div class=\"pZam\">
                <div id=\"pZaP\" class=\"c\">Witaj ";
        // line 161
        echo twig_escape_filter($this->env, ($context["imie"] ?? null), "html", null, true);
        echo "!<br>Tutaj będą się pojawiały<br>Twoje zamówienia.</div>
                <div id=\"pZaA\"></div>
                <div id=\"pZam\"></div>
            </div>
        </div>

        <div class=\"kat\">
            <div id=\"nKat\" class=\"nav\"></div>
            <div id=\"pKat\" class=\"pKat\">
                ";
        // line 170
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["kategorie"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["kategoria"]) {
            // line 171
            echo "                    <button class=\"cBattonKat\", onclick=\"otwKat('";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "IdKategorii", array()), "html", null, true);
            echo "')\", style=\"background-color: #";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "KolorKategorii", array()), "html", null, true);
            echo ";\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "NazwaKategorii", array()), "html", null, true);
            echo "</button>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['kategoria'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 173
        echo "            </div>
        </div>
    </div>

    <div>
        <div id=\"zeg\" class=\"zeg\"></div>
        <button id=\"sub2\" class=\"f1Batton\" onclick=\"zamPods()\" disabled>Podsumowanie</button>
        <button id=\"zamStart\" class=\"f2Batton\" onclick=\"zamStart()\">Anuluj zamówienie</button>
    </div>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/Layouts/zamowienie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  230 => 173,  217 => 171,  213 => 170,  201 => 161,  194 => 156,  191 => 155,  39 => 6,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/Layouts/zamowienie.html.twig", "C:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\Layouts\\zamowienie.html.twig");
    }
}

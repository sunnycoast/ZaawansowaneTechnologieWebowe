<?php

namespace MVC\Controller;

use Base\App;

class StartController extends App
{
    public function indexAction()
    {
        return $this->render('MVC/View/start.html.twig', array());
    }
}
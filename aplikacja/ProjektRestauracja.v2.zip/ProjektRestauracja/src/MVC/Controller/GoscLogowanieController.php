<?php

namespace MVC\Controller;

use Base\App;

class GoscLogowanieController extends App
{
    public function indexAction()
    {

        if( isset($_POST['imie']) && isset($_POST['l_os']) && isset($_POST['k_stol']))
        {
            $imie 	= $_POST['imie'];
            $l_os   = $_POST['l_os'];
            $k_stol = $_POST['k_stol'];
            $err = '';

            $em =$this-> getEntityManager();
            $stoliki = $em->getRepository('MVC\Model\Stolik')->findAll();

            foreach ($stoliki as $stolik)
            {
                if($stolik->getKodStolika() === $k_stol)
                {
                    if ($l_os <= ($stolik->getLiczbaMiejsc()-2))
                        $err="Uprzejmie prosilibyśmy o zmianę stolika na mniejszy.";
                    else
                    {
                        $sektor = $em->getRepository('MVC\Model\Sektor')->find($stolik->getIdSektora());
                        if (!$sektor->getAktywny())
                            $err = 'Przepraszamy sektor ' . $sektor->getNazwaSektora() . ' jest nie aktywny';
                        else
                        {
                            $err = 'przeszlo';
                        }
                    }
                }
            }
            if($err === '')
                $err = 'Niepoprawny kod stolika';

            $render = $this->render('MVC/View/gosc_logowanie.html.twig', array(
                'imie'   => $imie,
                'l_os'   => $l_os,
                'k_stol' => $k_stol,
                'err'    => $err
            ));
        } else
        {
            $render = $this->render('MVC/View/gosc_logowanie.html.twig', array(
                'imie'   => '',
                'l_os'   => '',
                'k_stol' => '',
                'err'    => ''
            ));
        }
        return $render;
    }
    /* //insert
        $books = new MVC();
        $books->setName('imie');
        $books->setDescription('desc');
        $em = $this->getEntityManager();
        $em->persist($books);
        $em->flush();
        //*/
    /* //select
    $em = $this->getEntityManager();
    $books = $em->getRepository('MVC\Model\Test')->find(3);
    //echo '<pre>';
    //print_r($books);
    //*/
    /* // update
    $em = $this->getEntityManager();
    $books = $em->getRepository('MVC\Model\MVC')->find(3);
    $books->setDescription('inny');
    $em->persist($books);
    $em->flush();
    //*/

    /* // select *

    $em = $this->getEntityManager();
    $books = $em->getRepository('MVC\Model\Test')->findAll();
    //*/
    //$query = $em->createQuery('SELECT u.id FROM books b');
    //$books = $query->getResult();

    //$query = $em->createQuery('SELECT b FROM books b WHERE b.id = :id');
    //$query->setParameter('id', '1');
    //$books = $query->getResult(); // array of ForumUser objects
    //*
    //$test = $this->getDoctrine()
    /*
            $minPrice = 10;

            $products = $this->getDoctrine()
                ->getRepository(Product::class)
                ->findAllGreaterThanPrice($minPrice);

            $em = $this->getEntityManager();
            $qb = $em->createQuery('SELECT l.id Books:books l');
            $books = $qb->getResult()
            //*/
    /*
    $em = $this->getEntityManager();
    $qb = new QueryBuilder( $em );
    $query = $qb  ->select('b.id')
                ->from('books', 'b')
                ->where('b.id = :nr')
                ->orderBy('b.id', 'ASC')
                ->setParameter('id', 1)
                ->getQuery();
    //$books =(array) $qb->expr();
    //*/
    // $query->useResultCache('my_cache_id');

    // Execute Query
    /*
    $em =$this-> getEntityManager();
    $books = $em->getRepository('MVC\Model\Test')->findAll();
    foreach ($books as $book)
    {
        $books2 =(array)$book;
        if($books2['']);
        //$newBooks[] = $book->toArray();
    }
    //*/
    /*
$em =$this-> getEntityManager();
$books = $em->getRepository('MVC\Model\Test')->findAll();

foreach ($books as $book)
{
    //$id = $book->getName();
if($book->getName() === 'imie2')
echo($book->getName());

}
die;


/*
$em =$this-> getEntityManager();
$qb = new QueryBuilder( $em );
$qb2 = $qb  ->select('b')
            ->from('Test', 'b')
            ->where('b.id = :nr')
            ->orderBy('b.id', 'ASC')
            ->setParameter('id', 1);

$query = $qb2->getQuery();
$results = $query->getResult();

//$books =(array) $qb2->expr();
echo gettype($results);
die;
//$t=new Test();
//$t->where($this->getEntityManager());
*/
/*
return $this->render('MVC\View\test.html.twig', array(
    'books'=> $newBooks,
));
//*/
}
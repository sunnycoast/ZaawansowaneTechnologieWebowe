<?php
/**
 * Created by PhpStorm.
 * User: Kacper
 * Date: 15.03.2018
 * Time: 19:55
 */

namespace MVC\Model;

/**
 * @Entity @Table(name="stklient")
 **/
class StalyKlient
{
    /** @Id @Column(type="integer") @GeneratedValue **/
    protected $id;

    /** @Column(type="string") **/
    protected $name;

    /** @Column(type="string") **/
    protected  $description;

    public function getID()
    {
        return $this->id;
    }

    public function setID($id)
    {
        $this->id = $id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }
}
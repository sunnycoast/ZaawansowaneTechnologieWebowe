<?php

/* MVC/View/gosc_logowanie.html.twig */
class __TwigTemplate_393b1c1ce78d47e57cd41a25436dc4be5424c6e8a52a352a4039053af732f0a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC/View/gosc_logowanie.html.twig", 1);
        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_sources($context, array $blocks = array())
    {
        // line 4
        echo "    <title>Projekt Restauracja</title>
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script type=\"text/javascript\" src=\"";
        // line 6
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/zegar.js")), "html", null, true);
        echo "\"></script>
    <script>
        window.onload=zegar;
    </script>
    <style>
        .nf
        {
            text-align: right;
            font-size: 20px;
            width: 110px;
            position: relative;
            display: inline-block;
        }

        span
        {
            margin-left: 45%;
            margin-top: 5px;
            text-align: center;
            display: block;
            width: 200px;
            font-size: 18px;
            max-width: 400px;
            color: #AA0000;
        }

        span:empty
        {
            visibility: hidden;
            min-height: 0px;
        }

        .my_form
        {
            min-height: 300px;
        }

        .zeg
        {
            margin-top: 30px;
            margin-bottom: 53px;
            z-index: 1;
            margin-left: 45%;
            width: 10%;
            display: block;
            text-align: center;
            position: relative;
            color: black;
            font-size: 20px;
        }

        .yII
        {
            font-size: 20px;
            padding: 7px;
            padding-right: 15px;
            padding-left: 15px;
            border-radius: 20px;
            background-color: red;
            margin-top: 20px;
            border-style: none;
            box-shadow: 3px 3px #AA000088;
        }
    </style>
";
    }

    // line 72
    public function block_content($context, array $blocks = array())
    {
        // line 73
        echo "<header>
    <p class=\"tytul\">Projekt Restauracja</p>
</header>

<div>
    <form class=\"my_form c\" action=\"gosc_autentykacja.php\" method=\"post\">
        <span id=\"err0\"><?php echo \$ogl_err; ?></span>
        <div class=\"nf\">Imię:</div>
        <input class=\"yI\" type=\"text\" name=\"imie\" value=\"<?=\$imie?>\" autocomplete=\"off\" required><br/>

        <div class=\"nf\">Liczba osób:</div>
        <input class=\"yI\" type=\"number\" name=\"l_os\" value=\"<?=\$l_os?>\" autocomplete=\"off\" required><br/>

        <div class=\"nf\">Kod stolika: </div>
        <input class=\"yI\" type=\"text\" name=\"k_stol\" value=\"<?=\$k_stol?>\" autocomplete=\"off\" required><br/>
        <input class=\"yII\" type=\"submit\" value=\"Otwórz rachunek\"><br/>
        <input class=\"yII\" type=\"button\" value=\"Powrót\" onclick=\"window.location.href='start.php';\">
    </form>

    <div id=\"zeg\" class=\"zeg\"></div>
</div>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/gosc_logowanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 73,  108 => 72,  39 => 6,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/gosc_logowanie.html.twig", "C:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\gosc_logowanie.html.twig");
    }
}

<?php

/* MVC/View/Layouts/main.html.twig */
class __TwigTemplate_b52ff0017c159f6638751b898069ff343fe7db01d801cde8111b58b5f607280d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"pl\">
<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"description\" content=\"System pozwalający na zamawianie przez internet.\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    ";
        // line 9
        $this->displayBlock('sources', $context, $blocks);
        // line 10
        echo "
</head>
<body>

    ";
        // line 14
        $this->displayBlock('main', $context, $blocks);
        // line 15
        echo "
    </div>
    <footer id=\"cOrder\">
        <details>
            <summary>Copyright 2018. All Rights Reserved &copy;</summary>
            <p>Śledź Kacper, Jonasz Śmietana, Ewa Skórska, Przemysław Fułek, PWr W8 ZTW - lab lato 2017/2018<p>
        </details>
    </footer>
</body>
";
    }

    // line 9
    public function block_sources($context, array $blocks = array())
    {
    }

    // line 14
    public function block_main($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  59 => 14,  54 => 9,  41 => 15,  39 => 14,  33 => 10,  31 => 9,  21 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/Layouts/main.html.twig", "D:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\Layouts\\main.html.twig");
    }
}

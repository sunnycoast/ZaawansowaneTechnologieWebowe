<?php

/* MVC/View/pracownik_logowanie.html.twig */
class __TwigTemplate_aebd3bb749066c3775cb729182d3f61c7848ff6a8776fe5c145ff0c8e1d411fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/login.html.twig", "MVC/View/pracownik_logowanie.html.twig", 1);
        $this->blocks = array(
            'target' => array($this, 'block_target'),
            'form' => array($this, 'block_form'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/login.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_target($context, array $blocks = array())
    {
        // line 4
        echo "    /pracownik_logowanie
";
    }

    // line 7
    public function block_form($context, array $blocks = array())
    {
        // line 8
        echo "    <div class=\"nf\">PIN:</div>
    <input class=\"yI\" type=\"password\" pattern=\"[0-9][0-9][0-9][0-9]\" inputmode=\"numeric\" name=\"pin\" value=\"\" autocomplete=\"off\" required><br/>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/pracownik_logowanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 8,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/pracownik_logowanie.html.twig", "D:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\pracownik_logowanie.html.twig");
    }
}

<?php

/* MVC/View/gosc_logowanie.html.twig */
class __TwigTemplate_4b7b1ba58ef29743d5c6a9e134866a1de5e899b1f9939743f204b42678d8988f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/login.html.twig", "MVC/View/gosc_logowanie.html.twig", 1);
        $this->blocks = array(
            'target' => array($this, 'block_target'),
            'form' => array($this, 'block_form'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/login.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_target($context, array $blocks = array())
    {
        // line 4
        echo "    /gosc_logowanie
";
    }

    // line 7
    public function block_form($context, array $blocks = array())
    {
        // line 8
        echo "    <div class=\"nf\">Imię:</div>
    <input class=\"yI\" type=\"text\" name=\"imie\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["imie"] ?? null), "html", null, true);
        echo "\" autocomplete=\"off\" required><br/>

    <div class=\"nf\">Liczba osób:</div>
    <input class=\"yI\" type=\"number\" name=\"l_os\" value=\"";
        // line 12
        echo twig_escape_filter($this->env, ($context["l_os"] ?? null), "html", null, true);
        echo "\" autocomplete=\"off\" required><br/>

    <div class=\"nf\">Kod stolika: </div>
    <input class=\"yI\" type=\"text\" name=\"k_stol\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, ($context["k_stol"] ?? null), "html", null, true);
        echo "\" autocomplete=\"off\" required><br/>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/gosc_logowanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 15,  49 => 12,  43 => 9,  40 => 8,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/gosc_logowanie.html.twig", "D:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\gosc_logowanie.html.twig");
    }
}

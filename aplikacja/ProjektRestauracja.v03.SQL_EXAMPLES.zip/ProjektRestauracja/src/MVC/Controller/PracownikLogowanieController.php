<?php

namespace MVC\Controller;

use Base\App;

class PracownikLogowanieController extends App
{
    public function indexAction()
    {
        if( isset($_POST['pin']) )
        {
            $pin 	= $_POST['pin'];
            $err = 'przeszlo';
            $password=$pin;
            $salt="abcd";#sól. można ustawić na dowolną stałą
            #no chyba, że chcemy dla każdego użytkownika tworzyć osobną sól
            #ale to jest zbyt pracochłonne
            $pass = $password.$salt;#solenie to zwykła konkatenacja stringów
            $hash = hash('sha256', $pass);#hashowanie bezpieczną metodą wbudowaną
            $err = $err." sha256+sól \"abcd\": ".$hash;
            $em = $this->getDoctrine()->provide();
            $sql = " 
                SELECT IdPracownika
                  FROM pracownicy
                  WHERE PIN LIKE ".$pin."
            ";
            $stmt = $em->getConnection()->prepare($sql);
            $stmt->execute();
            $product=$stmt->fetchAll();
            $id_prac=$product[0]["IdPracownika"];
            $err = $err." ".$id_prac;


            $render = $this->render('MVC/View/pracownik_logowanie.html.twig', array(
                'err'    => $err
            ));
        } else
        {
            $render = $this->render('MVC/View/pracownik_logowanie.html.twig', array(
                'err'    => ''
            ));
        }
        return $render;
    }
}
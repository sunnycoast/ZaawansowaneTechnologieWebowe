<?php

namespace MVC\Model;

/**
 * @Entity @Table(name="pozycje_menu")
 **/
class PozycjaMenu
{
    /** @Id @Column(type="integer") @GeneratedValue */
    protected $IdPozycjiMenu;

    /** @Column(type="float") */
    protected $CenaBrutto;

    /** @Column(type="date") */
    protected $DataWprowadzenia;

    /** @Column(type="date") */
    protected $DataWycofania;

    /**
     * @ManyToOne (targetEntity = "Produkt")
     * @JoinColumn (name = "IdProduktu", referencedColumnName = "id")
     * @Column(type="integer")
     */
    protected $IdProduktu;

    /**
     * @ManyToOne (targetEntity = "VAT")
     * @JoinColumn (name = "IdVAT", referencedColumnName = "id")
     * @Column(type="integer")
     */
    protected $IdVAT;

    /* * @OneToMany(targetEntity="PozycjaZamowienia", mappedBy="pozycje_zamówienia") */    /*
    protected $IdPozycjiZamowienia;

    public function __construct()
    {
        $this->IdPozycjiZamowienia = new ArrayCollection();
    }
    */
    public function getIdPozycjiMenu()
    {    return $this->IdProduktu;    }

    public function getCenaBrutto()
    {    return $this->CenaBrutto;    }

    public function setCenaBrutto($CenaBrutto)
    {    $this->CenaBrutto = $CenaBrutto;    }

    public function getDataWprowadzenia()
    {    return $this->DataWprowadzenia;    }

    public function setDataWprowadzenia($DataWprowadzenia)
    {    $this->DataWprowadzenia = $DataWprowadzenia;    }

    public function getDataWycofania()
    {    return $this->DataWycofania;    }

    public function setDataWycofania($DataWycofania)
    {    $this->DataWycofania = $DataWycofania;    }

    public function getIdProduktu()
    {    return $this->IdProduktu;    }

    public function setIdProduktu($IdProduktu)
    {    $this->IdProduktu = $IdProduktu;    }

    public function getIdVAT()
    {    return $this->IdVAT;    }

    public function setIdVAT($IdVAT)
    {    $this->IdVAT = $IdVAT;    }
    /*
    public function getIdPozycjiZamowienia()
    {    return $this->IdPozycjiZamowienia;    }
    */
}
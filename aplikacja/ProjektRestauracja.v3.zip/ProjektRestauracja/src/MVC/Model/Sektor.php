<?php

namespace MVC\Model;

/**
 * @Entity @Table(name="sektory")
 **/
class Sektor
{
    /**
     * @var integer
     *
     * @ORM\ManyToOne(targetEntity="Stolik")
     * @ORM\JoinColumn(name="stoliki", referencedColumnName="IdSektora")
     * @Id @Column(type="integer") @GeneratedValue
     **/
    protected $IdSektora;

    /** @Column(type="string") **/
    protected $NazwaSektora;

    /** @Column(type="boolean") **/
    protected  $Aktywny;

    /** @OneToMany(targetEntity="Stolik", mappedBy="sektory") **/
    private $IdStolika;

    public function __construct()
    {    $this->IdStolika = new ArrayCollection();    }

    public function getIdSektora()
    {    return $this->IdSektora;    }

    public function getNazwaSektora()
    {    return $this->NazwaSektora;    }

    public function setNazwaSektora($NazwaSektora)
    {    $this->NazwaSektora = $NazwaSektora;    }

    public function getAktywny()
    {    return $this->Aktywny;    }

    public function setAktywny($Aktywny)
    {    $this->Aktywny = $Aktywny;    }

    public function getIdStolika()
    {    return $this->IdStolika;    }

}
<?php

namespace MVC\Model;

use Doctrine\ORM\QueryBuilder;

/**
 * @Entity @Table(name="books")
 **/
class Test
{
    /** @Id @Column(type="integer") @GeneratedValue **/
    protected $id;

    /** @Column(type="string") **/
    protected $name;

    /** @Column(type="string") **/
    protected  $description;

    public function getID()
    {
        return $this->id;
    }

    // NOTE: ->where() overrides all previously set conditions
    //
    // Example - $qb->where('u.firstName = ?1', $qb->expr()->eq('u.surname', '?2'))
    // Example - $qb->where($qb->expr()->andX($qb->expr()->eq('u.firstName', '?1'), $qb->expr()->eq('u.surname', '?2')))
    // Example - $qb->where('u.firstName = ?1 AND u.surname = ?2')
    public function where()
    {
        // NOTE: ->where() overrides all previously set conditions
        //

        $em = $this->getEntityMenager();
        $qb = new QueryBuilder($em );
        $qb2 = $qb  ->select('b')
            ->from('books', 'b')
            ->where('b.id = :nr')
            ->orderBy('b.id', 'ASC')
            ->setParameter('id', 1);
        //$books =(array) $qb->expr();
        //*/
        $query = $qb2->getQuery();

        // $query->useResultCache('my_cache_id');

// Execute Query
        $books = $query->getSingleResult();
        echo gettype($books);
        die;

    }

    public function setID($id)
    {
        $this->id = $id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }
}
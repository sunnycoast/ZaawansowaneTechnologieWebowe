<?php

namespace MVC\Controller;

use Symfony\Component\HttpFoundation\Response;
use MVC\Model\Test;
use Base\App;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\QueryBuilder;

class TestController extends App
{
    /**
     * @return Response
     */
    public function indexAction()
    {
        /* //insert
        $books = new MVC();
        $books->setName('imie');
        $books->setDescription('desc');
        $em = $this->getEntityManager();
        $em->persist($books);
        $em->flush();
        //*/
        /* //select
        $em = $this->getEntityManager();
        $books = $em->getRepository('MVC\Model\MVC')->find(3);
        echo '<pre>';
        print_r($books);
        //*/
        /* // update
        $em = $this->getEntityManager();
        $books = $em->getRepository('MVC\Model\MVC')->find(3);
        $books->setDescription('inny');
        $em->persist($books);
        $em->flush();
        //*/

        /* // select *

        $em = $this->getEntityManager();
        $books = $em->getRepository('MVC\Model\Test')->findAll();
        //*/
        //$query = $em->createQuery('SELECT u.id FROM books b');
        //$books = $query->getResult();

        //$query = $em->createQuery('SELECT b FROM books b WHERE b.id = :id');
        //$query->setParameter('id', '1');
        //$books = $query->getResult(); // array of ForumUser objects
        //*
        //$test = $this->getDoctrine()

        $minPrice = 10;

        $products = $this->getDoctrine()
            ->getRepository(Product::class)
            ->findAllGreaterThanPrice($minPrice);
        
        $em = $this->getEntityManager();
        $qb = $em->createQuery('SELECT l.id Books:books l');
        $books = $qb->getResult();
        /*
        $em = $this->getEntityManager();
        $qb = new QueryBuilder( $em );
        $query = $qb  ->select('b.id')
                    ->from('books', 'b')
                    ->where('b.id = :nr')
                    ->orderBy('b.id', 'ASC')
                    ->setParameter('id', 1)
                    ->getQuery();
        //$books =(array) $qb->expr();
        //*/
       // $query->useResultCache('my_cache_id');

// Execute Query
        //echo gettype($books);
        //die;

        return $this->render('MVC\View\test.html.twig', array(
            'books'=> $books,
        ));
    }
}
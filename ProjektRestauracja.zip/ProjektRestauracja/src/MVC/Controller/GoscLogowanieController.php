<?php

namespace MVC\Controller;

use Base\App;

class GoscLogowanieController extends App
{
    public function indexAction()
    {
        if( isset($_POST['imie']) && isset($_POST['l_os']) && isset($_POST['k_stol']))
        {
            $imie 	= $_POST['imie'];
            $l_os   = $_POST['l_os'];
            $k_stol = $_POST['k_stol'];
            $err = 'przeszlo';



            $render = $this->render('MVC/View/gosc_logowanie.html.twig', array(
                'imie'   => $imie,
                'l_os'   => $l_os,
                'k_stol' => $k_stol,
                'err'    => $err
            ));
        } else
        {
            $render = $this->render('MVC/View/gosc_logowanie.html.twig', array(
                'imie'   => '',
                'l_os'   => '',
                'k_stol' => '',
                'err'    => ''
            ));
        }
        return $render;
    }
}
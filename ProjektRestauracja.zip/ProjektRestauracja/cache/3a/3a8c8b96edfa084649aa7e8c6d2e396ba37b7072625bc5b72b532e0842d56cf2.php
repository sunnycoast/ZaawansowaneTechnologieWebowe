<?php

/* MVC/View/Layouts/main.html.twig */
class __TwigTemplate_be68d99849e0d5491d97f23f6a6c17003039487a1cbd7c471de893e89263da72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"pl\">
<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"description\" content=\"System pozwalający na zamawianie przez internet.\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Projekt Restauracja</title>

    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script type=\"text/javascript\" src=\"";
        // line 11
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/zegar.js")), "html", null, true);
        echo "\"></script>
    <!--
    <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>
    -->
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">
 </head>
<body>
    <div class=\"container\">

        <h1>123</h1>
        ";
        // line 22
        $this->displayBlock('content', $context, $blocks);
        // line 23
        echo "    </div>
    <footer id=\"cOrder\">
        <details>
            <summary>Copyright 2018. All Rights Reserved &copy;</summary>
            <p>Śledź Kacper, Jonasz Śmietana, Ewa Skórska, Przemysław Fułek, PWr W8 ZTW - lab lato 2017/2018<p>
        </details>
    </footer>
</body>
";
    }

    // line 22
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 22,  51 => 23,  49 => 22,  35 => 11,  31 => 10,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/Layouts/main.html.twig", "C:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\Layouts\\main.html.twig");
    }
}

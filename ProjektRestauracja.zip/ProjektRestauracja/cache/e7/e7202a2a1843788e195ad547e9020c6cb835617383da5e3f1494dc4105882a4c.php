<?php

/* MVC\View\test.html.twig */
class __TwigTemplate_ccb89fecd9d7230075f9f686a52915962905916fd443aed57cd1fdd3fbe68b9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC\\View\\test.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "<h1>Records</h1>
<table>
    <tr>
        <th>nazwa</th>
        <th>opis</th>
        <th>akcja</th>
        <th>";
        // line 9
        echo twig_escape_filter($this->env, ($context["page"] ?? null), "html", null, true);
        echo "</th>
        <th>";
        // line 10
        echo twig_escape_filter($this->env, ($context["test"] ?? null), "html", null, true);
        echo "</th>
    </tr>
    ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["books"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 13
            echo "        <tr>
            <td>";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "name", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "description", array()), "html", null, true);
            echo "</td>
            <td><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("books", array("page" => 222, "test" => "sdfsd"))), "html", null, true);
            echo "\">Edytuj</a> </td>
        </tr>


    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "</table>

";
    }

    public function getTemplateName()
    {
        return "MVC\\View\\test.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 21,  63 => 16,  59 => 15,  55 => 14,  52 => 13,  48 => 12,  43 => 10,  39 => 9,  31 => 3,  28 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC\\View\\test.html.twig", "C:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\test.html.twig");
    }
}

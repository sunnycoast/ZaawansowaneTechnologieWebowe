<?php

/* MVC\View\test.html.twig */
class __TwigTemplate_381e64bed9861ecb523c86d484afb82daaa82d6ba812a554cd287d446969d245 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo twig_escape_filter($this->env, ($context["page"] ?? null), "html", null, true);
        echo "
<br>
";
        // line 3
        echo twig_escape_filter($this->env, ($context["test"] ?? null), "html", null, true);
    }

    public function getTemplateName()
    {
        return "MVC\\View\\test.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  24 => 3,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC\\View\\test.html.twig", "C:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\test.html.twig");
    }
}

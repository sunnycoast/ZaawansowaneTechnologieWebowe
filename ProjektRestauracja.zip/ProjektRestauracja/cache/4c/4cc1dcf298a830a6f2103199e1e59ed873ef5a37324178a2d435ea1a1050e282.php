<?php

/* MVC/View/Layouts/main.html.twig */
class __TwigTemplate_5d68d5a8b1218bdc26be82c61b1d62f163477d348a10aa27ed79c2dd6d324349 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<head>
    <script type=\"text/javascript\" src=\"asset/js/zegar.js\"></script>
</head>
<body>
    <h1>123</h1>
    ";
        // line 6
        $this->displayBlock('content', $context, $blocks);
        // line 7
        echo "    <h1>456</h1>
</body>
";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  35 => 6,  29 => 7,  27 => 6,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/Layouts/main.html.twig", "C:\\xampp\\htdocs\\ProjektRestauracja\\src\\MVC\\View\\Layouts\\main.html.twig");
    }
}

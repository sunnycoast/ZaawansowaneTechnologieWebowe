<?php

/* MVC/View/staly_klient_logowanie.html.twig */
class __TwigTemplate_db67c8e0b3b711e0f9bace274a7cd6d93378328127e670fc8d0dd7af11d63685 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/login.html.twig", "MVC/View/staly_klient_logowanie.html.twig", 1);
        $this->blocks = array(
            'target' => array($this, 'block_target'),
            'form' => array($this, 'block_form'),
            'register' => array($this, 'block_register'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/login.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_target($context, array $blocks = array())
    {
        // line 4
        echo "    /staly_klient_logowanie
";
    }

    // line 7
    public function block_form($context, array $blocks = array())
    {
        // line 8
        echo "    <div class=\"nf\">e-mail:</div>
    <input class=\"yI\" type=\"email\" name=\"email\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["email"] ?? null), "html", null, true);
        echo "\" autocomplete=\"off\" required><br/>

    <div class=\"nf\">hasło:</div>
    <input class=\"yI\" type=\"password\" name=\"haslo\" value=\"\" autocomplete=\"off\" required><br/>
";
    }

    // line 15
    public function block_register($context, array $blocks = array())
    {
        // line 16
        echo "    <div  class=\"my_form c\">
    <div class=\"nf\">Nie masz konta? Zarejestruj się!</div>
        <div> <input class=\"yII\" type=\"button\" value=\"Stwórz konto\" onclick=\"window.location.href='/staly_klient_zaloz_konto';\"></div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/staly_klient_logowanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 16,  53 => 15,  44 => 9,  41 => 8,  38 => 7,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/staly_klient_logowanie.html.twig", "C:\\xampp\\htdocs\\ZTW\\src\\MVC\\View\\staly_klient_logowanie.html.twig");
    }
}

<?php

/* MVC/View/zamowienie_zakoncz.html.twig */
class __TwigTemplate_c3e3d4ed4a2da8266800561840c46b2e2b713be68b608d2360db95846e933a28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC/View/zamowienie_zakoncz.html.twig", 1);
        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_sources($context, array $blocks = array())
    {
        // line 4
        echo "    <title>Projekt Restauracja</title>
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script>
        let log_address = \"";
        // line 7
        echo twig_escape_filter($this->env, ($context["log_adres"] ?? null), "html", null, true);
        echo "\";
        let payment = \"";
        // line 8
        echo twig_escape_filter($this->env, ($context["payment"] ?? null), "html", null, true);
        echo "\";
        let order = [];
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["rachunek"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["pz"]) {
            // line 11
            echo "            order.push({\"NazwaProduktu\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "NazwaProduktu", array()), "html", null, true);
            echo "\", \"opis\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "Opis", array()), "html", null, true);
            echo "\", \"CenaBrutto\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "CenaBrutto", array()), "html", null, true);
            echo ", \"StawkaVAT\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "StawkaVAT", array()), "html", null, true);
            echo ", \"LiczbaProduktow\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "LiczbaProduktow", array()), "html", null, true);
            echo ", \"StanRealizacji\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "StanRealizacji", array()), "html", null, true);
            echo "});
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pz'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "    </script>
    <style>
        #suma
        {
            display: inline;
            white-space:nowrap;
            font-size: 26px;
        }

        body
        {
            margin: 0;
            padding: 0;
            font-size: 16px;
            box-sizing: border-box;
            background: lightgray; /* For browsers that do not support gradients */
            background: -webkit-linear-gradient(lightgray, steelblue); /* For Safari 5.1 to 6.0 */
            background: -o-linear-gradient(lightgray, steelblue); /* For Opera 11.1 to 12.0 */
            background: -moz-linear-gradient(lightgray, steelblue); /* For Firefox 3.6 to 15 */
            background: linear-gradient(lightgray, steelblue); /* Standard syntax */
        }

        @font-face

        {
            font-family: 'MyFont';
            /*src: url(RemachineScript.ttf);*/
        }

        p
        {
            text-align: center;
            font-family: 'MyFont', times new roman;
            font-size: 100px;
            color: red;
            font-weight: bold;
            text-shadow: 5px 5px #AA000088;
        }

        form
        {
            text-align: center;
        }

        input
        {
            margin-top: 10px;
            position: relative;
            background-color: yellow;
            color: black;
            font-size: 22px;
            height: 30px;
            width: 200px;
            cursor: pointer;
            border-radius: 5px;
        }

        input:hover
        {
            background-color: #FFFF44;
        }

        footer
        {
            position: relative;
            bottom: 0px;
            width: 99%;
            text-align: center;
            font-size: 0.8em;
            background: steelblue;
        }

        .f1Batton
        {
            margin-left: 29%;
            width: 42%;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 24px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .f2Batton
        {
            margin-left: 29%;
            margin-top: 2%;
            text-align: center;
            width: 42%;
            background-color: red;
            color: black;
            padding: 16px;
            font-size: 16px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .nf
        {
            text-align: left;
            width: 100px;
            position: relative;
            display: inline;
        }

        .b20px
        {
            display: block;
            margin-left: 35%;
            text-align: justify;
            width: 30%;
            font-size: 20px;
            font-weight: bold;
        }

        input
        {
            position: relative;
            display: inline;
        }

        form
        {
            padding-bottom: 0%;
            text-align: center;
            visibility: hidden;
        }

        .zeg
        {
            margin-top: 70px;
            margin-bottom: 74px;
            text-align: center;
            position: relative;
            color: black;
            font-size: 20px;
        }


        #cover
        {
            visibility: hidden;
            width: 100%;
            height: 100%;
            z-index: 1;
            position: absolute;
            background-color: #00000077;
            background-size: cover;
        }

        #cover > table
        {
            border-color: #c0c0c0;
            border-width: 2px 4px 4px 2px;
            margin: 0;
            padding: 0;
            position: absolute;
            z-index: 100;
            top: 30%;
            left: 38%;
            height: 20%;
            width: 24%;
            border-radius: 5%;
            background-color: #fff;
            text-align: center;
        }

        #alertTitle
        {
            border-radius: 40%;
            background-color: #B0B0B0;
            font-weight: bold;
            height: 20px;
            text-align: center;
        }

        #alertBs button
        {
            margin-top: 5%;
            border-radius: 10%;
            background-color: #E9E9CF;
            color: #000000;
            font-weight: bold;
            width: 125px;
            height: 33px;
            padding-left: 20px;
        }

        .relative
        {
            position: relative;
        }
    </style>
";
    }

    // line 215
    public function block_main($context, array $blocks = array())
    {
        // line 216
        echo "    <div id=\"cover\"></div>
    <header>
        <p>Projekt Restauracja</p>
    </header>
    <div class=\"b20px\">
        Dziękujemy za wizytę w naszej restauracji. Mamy nadzieję, że wszystko Państwu smakowało, zaraz do Państwa podejdzie kelner z rachunkiem.
    </div>
    <br>
    <div id=\"platnosc\" class=\"b20px\"></div>
    <button id=\"summary\" class=\"f1Batton\">Podgląd rachunku</button><br>
    <button id=\"end\" class=\"f2Batton\">Zakończ</button>
    <div id=\"zeg\" class=\"zeg\"></div>
    <script type=\"text/javascript\" src=\"";
        // line 228
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/jquery-3.2.1.min.js")), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 229
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/end.js")), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/zamowienie_zakoncz.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  297 => 229,  293 => 228,  279 => 216,  276 => 215,  72 => 13,  53 => 11,  49 => 10,  44 => 8,  40 => 7,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/zamowienie_zakoncz.html.twig", "C:\\xampp\\htdocs\\ZTW\\src\\MVC\\View\\zamowienie_zakoncz.html.twig");
    }
}

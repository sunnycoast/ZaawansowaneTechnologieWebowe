<?php

/* MVC/View/Layouts/main.html.twig */
class __TwigTemplate_2dc47956ab1f0edf62595affcc54c910588a5707ac16792d7a37c7b06112cc33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"pl\">
<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"description\" content=\"System pozwalający na zamawianie przez internet.\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    ";
        // line 9
        $this->displayBlock('sources', $context, $blocks);
        // line 10
        echo "</head>
<body>

    ";
        // line 13
        $this->displayBlock('main', $context, $blocks);
        // line 14
        echo "
    </div>
    <footer id=\"cOrder\">
        <details>
            <summary>Copyright 2018. All Rights Reserved &copy;</summary>
            <p>Śledź Kacper, Jonasz Śmietana, Ewa Skórska, Przemysław Fułek, PWr W8 ZTW - lab lato 2017/2018<p>
        </details>
    </footer>
</body>
";
    }

    // line 9
    public function block_sources($context, array $blocks = array())
    {
    }

    // line 13
    public function block_main($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  58 => 13,  53 => 9,  40 => 14,  38 => 13,  33 => 10,  31 => 9,  21 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/Layouts/main.html.twig", "C:\\xampp\\htdocs\\ZTW\\src\\MVC\\View\\Layouts\\main.html.twig");
    }
}

<?php

/* MVC/View/zamowienie.html.twig */
class __TwigTemplate_f57cd334a91025497287050e49efe5e10d8f81931288c751735fd75c159e755f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC/View/zamowienie.html.twig", 1);
        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_sources($context, array $blocks = array())
    {
        // line 4
        echo "    <title>Projekt Restauracja</title>
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script>
        let log_address = \"";
        // line 7
        echo twig_escape_filter($this->env, ($context["log_adres"] ?? null), "html", null, true);
        echo "\";
        let order = [];
        ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["order"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["pz"]) {
            // line 10
            echo "        order.push({\"idPM\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "IdPozycjiMenu", array()), "html", null, true);
            echo "\", \"LiczbaProduktow\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "LiczbaProduktow", array()), "html", null, true);
            echo "});
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pz'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "
        let tCat = [];
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["kategorie"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["kategoria"]) {
            // line 15
            echo "        tCat[";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "IdKategorii", array()), "html", null, true);
            echo "] = {\"id\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "IdKategorii", array()), "html", null, true);
            echo ", \"NazwaKategorii\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "NazwaKategorii", array()), "html", null, true);
            echo "\", \"KolorKategorii\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["kategoria"], "KolorKategorii", array()), "html", null, true);
            echo "\"};
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['kategoria'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "
        let tMI = [];
        ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["menu"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["pMenu"]) {
            // line 20
            echo "        tMI[";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "IdPozycjiMenu", array()), "html", null, true);
            echo "] = {\"idK\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "IdKategorii", array()), "html", null, true);
            echo ", \"idPM\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "IdPozycjiMenu", array()), "html", null, true);
            echo ", \"NazwaProduktu\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "NazwaProduktu", array()), "html", null, true);
            echo "\", \"CenaBrutto\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "CenaBrutto", array()), "html", null, true);
            echo ", \"Opis\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "Opis", array()), "html", null, true);
            echo "\", \"StawkaVAT\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pMenu"], "StawkaVAT", array()), "html", null, true);
            echo " };
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pMenu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "    </script>
    <script type=\"text/javascript\" src=\"";
        // line 23
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/zegar.js")), "html", null, true);
        echo "\"></script>
    <script>
        window.onload=zegar;
    </script>
    <style>

        .boix
        {
            padding: 2%;
            width: \t96%;
            height: 80%;
            display: -webkit-box;
            -webkit-box-orient: horizontal;
        }

        .pZam
        {    border: 3px solid steelblue;    }


        .pKat
        {
            border-top:    3px solid steelblue;
            border-right:  3px solid steelblue;
            border-bottom: 3px solid steelblue;
            height: 538px;
        }

        .cBattonNavZam
        {
            position: relative;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 16px;
            width: 99.6%;
            height: 10%;
            cursor: pointer;
            border-top-right-radius: 50px;
            border-top-left-radius:  10px;
        }

        .f1Batton
        {
            margin-left: 2%;
            width: 42%;
            position: relative;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 24px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .f2Batton
        {
            top: -50px;
            margin-left: 46%;
            width: 42%;
            position: relative;
            background-color: red;
            color: black;
            padding: 16px;
            font-size: 16px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .nav
        {
            position: relative;
            overflow: hidden;
            height: 54px;
        }

        .zeg
        {
            margin-left: 90%;
            width: 8%;
            text-align: center;
            position: absolute;
            color: black;
            font-size: 20px;
        }

        .cBattonKat
        {
            margin:2%;
            width:20%;
            height:13%;
            border-radius: 5px;
            cursor: pointer;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .c
        {    text-align: center;    }

        .cKategoria:hover .cDivOp
        {
            visibility: visible;
        }

        .boix > .zam
        {
            width: 33%;
            overflow: hidden;
        }

        .pZam
        {    height: 538px;    }

        .boix >.kat
        {    width: 67%;    }

        .pKat
        {    height: 538px;    }

        .greeting
        {
            margin-top: 200px;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
        }

        #cover
        {
            visibility: hidden;
            width: 100%;
            height: 100%;
            z-index: 1;
            position: absolute;
            background-color: #00000077;
            background-size: cover;
        }

        #cover table
        {
            border-color: #c0c0c0;
            border-width: 2px 4px 4px 2px;
            margin: 0;
            padding: 0;
            position: absolute;
            z-index: 100;
            top: 30%;
            left: 38%;
            height: 20%;
            width: 24%;
            border-radius: 5%;
            background-color: #fff;
            text-align: center;
        }

        #alertTitle
        {
            border-radius: 40%;
            background-color: #B0B0B0;
            font-weight: bold;
            height: 20px;
            text-align: center;
        }

        #alertBs button
        {
            margin-top: 5%;
            border-radius: 10%;
            background-color: #E9E9CF;
            color: #000000;
            font-weight: bold;
            width: 125px;
            height: 33px;
            padding-left: 20px;
        }

    </style>
";
    }

    // line 208
    public function block_main($context, array $blocks = array())
    {
        // line 209
        echo "    <div id=\"cover\"></div>
    <div class=\"boix\">
        <div class=\"zam\">
            <button id=\"sub1\" class=\"cBattonNavZam\">Zamówienie</button>
            <div class=\"pZam\">
                <div id=\"pZaP\" class=\"greeting\">Witaj ";
        // line 214
        echo twig_escape_filter($this->env, ($context["imie"] ?? null), "html", null, true);
        echo "!<br>Tutaj będą się pojawiały<br>Twoje zamówienia.</div>
                <div id=\"pZaA\"></div>
                <div id=\"pZaR\"></div>
            </div>
        </div>

        <div class=\"kat\">
            <div id=\"nKat\" class=\"nav\"></div>
            <div id=\"pKat\" class=\"pKat\"></div>
        </div>
    </div>
    <div>
        <div id=\"zeg\" class=\"zeg\"></div>
        <button id=\"sub2\" class=\"f1Batton\">Podsumowanie</button>
        <button id=\"zamStart\" class=\"f2Batton\">Anuluj zamówienie</button>
    </div>
    <script type=\"text/javascript\" src=\"";
        // line 230
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/jquery-3.2.1.min.js")), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 231
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/menu.js")), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 232
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/order.js")), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/zamowienie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  340 => 232,  336 => 231,  332 => 230,  313 => 214,  306 => 209,  303 => 208,  115 => 23,  112 => 22,  91 => 20,  87 => 19,  83 => 17,  68 => 15,  64 => 14,  60 => 12,  49 => 10,  45 => 9,  40 => 7,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/zamowienie.html.twig", "C:\\xampp\\htdocs\\ZTW\\src\\MVC\\View\\zamowienie.html.twig");
    }
}

<?php

/* MVC/View/zamowienie_podsumowanie.html.twig */
class __TwigTemplate_28f90ac3d418b19acae219e52f364644b2ff7e1b3527fc8b73b3b459db944897 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC/View/zamowienie_podsumowanie.html.twig", 1);
        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_sources($context, array $blocks = array())
    {
        // line 4
        echo "    <title>Projekt Restauracja</title>
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script>
        let order = [];
        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["rachunek"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["pz"]) {
            // line 9
            echo "            order.push({\"NazwaProduktu\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "NazwaProduktu", array()), "html", null, true);
            echo "\", \"opis\":\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "Opis", array()), "html", null, true);
            echo "\", \"CenaBrutto\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "CenaBrutto", array()), "html", null, true);
            echo ", \"StawkaVAT\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "StawkaVAT", array()), "html", null, true);
            echo ", \"LiczbaProduktow\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "LiczbaProduktow", array()), "html", null, true);
            echo ", \"StanRealizacji\":";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pz"], "StanRealizacji", array()), "html", null, true);
            echo "});
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pz'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "    </script>
    <style>
        .box
        {
            padding: 2%;
            width: \t100%;
            height: 100%;
            display: -webkit-box;
            -webkit-box-orient: horizontal;
        }

        .pZam
        {    border: 3px solid steelblue;    }


        .pKat
        {
            border: 3px solid steelblue;
            height: 600px;
        }

        .cBattonNavKat
        {
            position: relative;
            background-color: steelblue;
            color: black;
            padding: 16px;
            font-size: 16px;
            width: 49.5%;
            height: 10%;
            cursor: pointer;
            border-top-right-radius: 50px;
            border-top-left-radius:  10px;
        }

        .cBattonNavZam
        {
            position: relative;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 16px;
            width: 49.5%;
            height: 10%;
            cursor: pointer;
            border-top-right-radius: 50px;
            border-top-left-radius:  10px;
        }

        .f1Batton
        {
            margin-left: 2%;
            width: 42%;
            position: relative;
            background-color: gray;
            color: black;
            padding: 16px;
            font-size: 24px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .f2Batton
        {
            top: -50px;
            margin-left: 46%;
            width: 42%;
            position: relative;
            background-color: red;
            color: black;
            padding: 16px;
            font-size: 16px;
            height: 50px;
            cursor: pointer;
            border-radius: 10px;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .nav
        {
            position: relative;
            overflow: hidden;
            height: 54px;
        }

        .zeg
        {
            width: 8%;
            text-align: center;
            color: black;
            font-size: 20px;
        }

        .cBattonKat
        {
            margin:2%;
            width:20%;
            height:12%;
            border-radius: 5px;
            cursor: pointer;
            border-style: none;
            box-shadow: 4px 4px #666666;
        }

        .c
        {    text-align: center;    }

        .cKategoria:hover .cDivOp
        {
            visibility: visible;
        }


        .pZam
        {    height: 538px;    }


        .pKat
        {    height: 600px;    }

        #pZaP
        {
            margin-top: 200px;
            font-size: 24px;
            font-weight: bold;
        }

        .yII
        {
            font-size: 20px;
            padding: 7px;
            padding-right: 15px;
            padding-left: 15px;
            border-radius: 20px;
            background-color: red;
            margin-top: 20px;
            border-style: none;
            box-shadow: 3px 3px #AA000088;
        }

        .my_form
        {
            min-height:90px;
        }

        #cover
        {
            visibility: hidden;
            width: 100%;
            height: 100%;
            z-index: 1;
            position: absolute;
            background-color: #00000077;
            background-size: cover;
        }

        #cover table
        {
            border-color: #c0c0c0;
            border-width: 2px 4px 4px 2px;
            margin: 0;
            padding: 0;
            position: absolute;
            z-index: 100;
            top: 30%;
            left: 38%;
            height: 20%;
            width: 24%;
            border-radius: 5%;
            background-color: #fff;
            text-align: center;
        }

        #alertTitle
        {
            border-radius: 40%;
            background-color: #B0B0B0;
            font-weight: bold;
            height: 20px;
            text-align: center;
        }

        #alertBs button
        {
            margin-top: 5%;
            border-radius: 10%;
            background-color: #E9E9CF;
            color: #000000;
            font-weight: bold;
            width: 125px;
            height: 33px;
            padding-left: 20px;
        }

    </style>
";
    }

    // line 212
    public function block_main($context, array $blocks = array())
    {
        // line 213
        echo "    <div id=\"cover\"></div>
    <div class=\"box\">
        <div class=\"kat\">
            <div id=\"pKat\" class=\"pKat\"></div>
        </div>
    </div>
    <div>
        <button id=\"addOrder\" class=\"f1Batton\">Dodaj zamówienie</button>
        <button id=\"pay\" class=\"f2Batton\">Zapłać</button>
    </div>
    <script type=\"text/javascript\" src=\"";
        // line 223
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/jquery-3.2.1.min.js")), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 224
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/summary.js")), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/zamowienie_podsumowanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  286 => 224,  282 => 223,  270 => 213,  267 => 212,  64 => 11,  45 => 9,  41 => 8,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/zamowienie_podsumowanie.html.twig", "C:\\xampp\\htdocs\\ZTW\\src\\MVC\\View\\zamowienie_podsumowanie.html.twig");
    }
}

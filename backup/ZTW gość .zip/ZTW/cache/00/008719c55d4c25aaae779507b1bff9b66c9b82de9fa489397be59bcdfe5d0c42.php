<?php

/* MVC/View/start.html.twig */
class __TwigTemplate_a0d2f80c7c81e3238ccebfacf14d9e2b4b7b83ed3e468b47f48cd376e7401f91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MVC/View/Layouts/main.html.twig", "MVC/View/start.html.twig", 1);
        $this->blocks = array(
            'sources' => array($this, 'block_sources'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MVC/View/Layouts/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_sources($context, array $blocks = array())
    {
        // line 4
        echo "    <title>Projekt Restauracja</title>
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("css/main.css")), "html", null, true);
        echo "\"/>
    <script type=\"text/javascript\" src=\"";
        // line 6
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("js/zegar.js")), "html", null, true);
        echo "\"></script>
    <script>
        window.onload=zegar;
    </script>
    <style>
        .my_form
        {
            min-height: 300px;
        }

        .zeg
        {
            margin-top: 30px;
            margin-bottom: 53px;
            z-index: 1;
            margin-left: 45%;
            width: 10%;
            display: block;
            text-align: center;
            position: relative;
            color: black;
            font-size: 20px;
        }

        .yII
        {
            text-align: center;
            font-size: 20px;
            width: 220px;
            padding: 7px;
            padding-right: 15px;
            padding-left: 15px;
            border-radius: 20px;
            background-color: red;
            margin-top: 20px;
            border-style: none;
            box-shadow: 3px 3px #AA000088;
        }
    </style>
";
    }

    // line 47
    public function block_main($context, array $blocks = array())
    {
        // line 48
        echo "<header>
    <p class=\"tytul\">Projekt Restauracja</p>
</header>

<div>

    <form class=\"my_form c\">
        <input class=\"yII\" type=\"button\" value=\"Zaloguj\" onclick=\"window.location.href='/staly_klient_logowanie';\"><br>
        <input class=\"yII\" type=\"button\" value=\"Jestem w restauracji\" onclick=\"window.location.href='/gosc_logowanie';\"><br>
        <input class=\"yII\" type=\"button\" value=\"Nasze Menu\" onclick=\"window.location.href='/menu';\"><br>
        <input class=\"yII\" type=\"button\" value=\"Podgląd sali\" onclick=\"window.location.href='/podglad_sali';\">
    </form>

    <div id=\"zeg\" class=\"zeg c\"></div>

</div>
";
    }

    public function getTemplateName()
    {
        return "MVC/View/start.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 48,  83 => 47,  39 => 6,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "MVC/View/start.html.twig", "C:\\xampp\\htdocs\\ZTW\\src\\MVC\\View\\start.html.twig");
    }
}
